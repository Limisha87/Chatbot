// ================= PAGE LOAD =================
// Run this function when the page is fully loaded
window.onload = function() {
    // Get the chatbot icon element
    const icon = document.getElementById("chatIcon");

    // Add click event to the icon (toggle open/close)
    icon.onclick = function() {
        // Get the chatbot container
        const chatBox = document.getElementById("chatBox");

        // Check if chatbot is already open
        if (chatBox.style.display === "flex") {
            // If open → close the chatbot
            chatBox.style.display = "none";
        } else {
            // If closed → open the chatbot
            chatBox.style.display = "flex";

            // Show home screen when chatbot opens
            showHome();
        }
    };
};

// ================= CLOSE BOT =================

function closeBot() {
    document.getElementById("chatBox").style.display = "none";
}
// ================= GLOBAL VARIABLES =================

// History stack (back navigation ke liye)
let historyStack = [];

// Active data (user ya nutritionist)
let activeData = null;

// Cache (fast response ke liye)
let cache = {};

// ================= MENU DATA =================
const menuData = {
    "About TrackIntake": "TrackIntake is an AI-powered nutrition and health tracking platform that helps you log your daily meals, monitor your nutrition, and receive personalized diet recommendations.",
    "Data & Security": "Your data is safe, secure, and never shared without your permission.",
    "Contact Us": "📞 7898622813"
};

// ================= USER FAQ =================
const userFAQs = {
    "How to Use": [
        { q: "How do I start using TrackIntake?" },
        { q: "What details are required first?" },
        { q: "Is it easy for beginners?" },
        { q: "Do I need to use it daily?" },
        { q: "Can I skip profile setup?" }
    ],

    "Track Meals": [
        { q: "How do I log my meals?" },
        { q: "Can I edit my meals later?" },
        { q: "How are meals organized?" },
        { q: "Does it support Indian food?" },
        { q: "Is there a food search option?" }
    ],

    "Diet Plans": [
        { q: "How do I get diet plans?" },
        { q: "Are diet plans personalized?" },
        { q: "Can I follow plans without a nutritionist?" },
        { q: "Will veg preference be followed?" },
        { q: "Are diet plans accurate?" }
    ],

    "Health Tracking": [
        { q: "What health tools are available?" },
        { q: "Can I track my BMI?" },
        { q: "Can I track water intake?" },
        { q: "Can I track my weight?" },
        { q: "Is this platform suitable for diabetes or heart patients?" }
    ],

    "My Progress": [
        { q: "Can I see my progress?" },
        { q: "What does the dashboard show?" },
        { q: "Can I track long-term progress?" },
        { q: "Does it help with motivation?" },
        { q: "Is progress tracking automatic?" }
    ],



    "Help & Support": [
        { q: "Can I contact support?" },
        { q: "Can I consult a nutritionist?" },
        { q: "What should I do if I face issues?" },
        { q: "Is help available anytime?" },
        { q: "Can I give feedback?" }
    ]

};
// ================= NUTRITIONIST FAQ =================
const nutritionistFAQs = {
    "How to Use": [
        { q: "How do I start using TrackIntake as a nutritionist?" },
        { q: "What details are required during setup?", },
        { q: "Is the platform easy to use?" },
        { q: "Do I need training before using it?" },
        { q: "Can I start working immediately?" }
    ],

    "Patients": [
        { q: "Can I manage multiple patients?" },
        { q: "Can I monitor patients daily?" },
        { q: "Can I get new patients through the platform?" },
        { q: "How can I track patient progress?" },
        { q: "Is patient data easy to access?" }
    ],

    "Diet Plans": [
        { q: "How do I create diet plans?" },
        { q: "Can I customize diet plans?" },
        { q: "Does the system support Indian diets?" },
        { q: "Can I reuse diet plans?" },
        { q: "Does AI help in diet planning?" }
    ],

    "Consultations": [
        { q: "Can I conduct online consultations?" },
        { q: "Can I communicate with patients easily?" },
        { q: "Can I schedule consultations?" },
        { q: "Is follow-up support available?" },
        { q: "Is it convenient for both sides?" }
    ],

    "Earnings": [
        { q: "How can I earn through TrackIntake?" },
        { q: "Are there multiple earning options?" },
        { q: "Can I set my own pricing?" },
        { q: "Can this help grow my practice?" },
        { q: "Can I track my earnings?" }
    ],

    "Reports": [
        { q: "Can I generate patient reports?" },
        { q: "What insights are available?" },
        { q: "Can I track long-term progress?" },
        { q: "Are reports easy to understand?" },
        { q: "Can I use data for research?" }
    ],

    "Help & Support": [
        { q: "What should I do if I face issues?" },
        { q: "Is technical support available?" },
        { q: "Can I request a demo?" },
        { q: "How can I contact support?" },
        { q: "Can I give feedback?" }
    ]

};

// ================= OPEN BOT =================
function openBot() {
    document.getElementById("chatBox").style.display = "flex";
    showHome(); // Home screen show karo
}

// ================= HOME SCREEN =================
function showHome() {

    // History reset
    historyStack = [];

    // HTML dynamically inject karo
    document.getElementById("content").innerHTML = `
    <div style="text-align:center;padding:20px;">
      <h3>Welcome To TrackIn-Take 👋</h3>
      <h5>Please Choose a category</h5>

      <div class="btn-group">
        <button class="btn user" onclick="openSection('user')">User</button>
        <button class="btn nutrition" onclick="openSection('nutrition')">Nutritionist</button>
      </div>
    </div>
  `;
}

// ================= BACK FUNCTION =================
function goBack() {

    // Menu close karo
    menuOpen = false;
    activeMenu = null;
    document.getElementById("menuPanel").style.display = "none";

    // Previous screen show karo
    if (historyStack.length > 0) {
        document.getElementById("content").innerHTML = historyStack.pop();
    }
}

// ================= SHOW QUESTIONS =================
function showQ(cat) {

    // Current screen save karo
    historyStack.push(document.getElementById("content").innerHTML);

    let faqs = activeData[cat];
    let html = "";

    // Questions loop
    faqs.forEach((item, i) => {
        html += `
      <div class="question" onclick="getAnswer(this, ${i})">${item.q}</div>
      <div class="answer" id="ans${i}"></div>
    `;
    });

    document.getElementById("content").innerHTML = html;
}

// ================= GET ANSWER FROM API =================
async function getAnswer(el, i) {

    let question = el.innerText;
    let ansEl = document.getElementById("ans" + i);

    ansEl.innerText = "⏳ Loading...";
    ansEl.style.display = "block";

    try {

        let res = await fetch("http://127.0.0.1:8000/api/chat/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ question: question })
        });

        let data = await res.json();

        ansEl.innerText = data.answer;

    } catch (err) {
        console.error(err);
        ansEl.innerText = "⚠️ Server error";
    }
}

// ================= OPEN SECTION =================
function openSection(type) {

    // Save current page
    historyStack.push(document.getElementById("content").innerHTML);

    // Set active data
    activeData = (type === "user") ? userFAQs : nutritionistFAQs;

    // Page title
    let title = (type === "user") ? "👤 User Page" : "🥗 Nutritionist Page";

    let html = `
    <div style="text-align:center; padding:10px;">
      <h3 style="color:#f97316;">${title}</h3>
    </div>

    <div class="section-container">
  `;

    // Categories loop
    for (let cat in activeData) {
        html += `<button class="section-btn" onclick="showQ('${cat}')">${cat}</button>`;
    }

    html += `</div>`;

    document.getElementById("content").innerHTML = html;
}

// ================= MENU =================
let menuOpen = false,
    activeMenu = null;

// Menu toggle
function toggleMenu() {
    menuOpen = !menuOpen;
    renderMenu();
}

// Render menu items
function renderMenu() {

    let panel = document.getElementById("menuPanel");

    if (!menuOpen) {
        panel.style.display = "none";
        return;
    }

    panel.style.display = "block";
    panel.innerHTML = "";

    Object.keys(menuData).forEach(item => {
        panel.innerHTML += `
      <div>
        <div class="menu-title" onclick="toggleMenuItem('${item}')">
          ${item} <span>${activeMenu===item?"▼":">"}</span>
        </div>
        <div class="menu-content" style="display:${activeMenu===item?'block':'none'}">
          ${menuData[item]}
        </div>
      </div>`;
    });
}

// Open/close menu item
function toggleMenuItem(item) {
    if (activeMenu === item) {
        activeMenu = null;
    } else {
        activeMenu = item;
    }
    renderMenu();
}